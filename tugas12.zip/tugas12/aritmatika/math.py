def add(num1,num2):
    return num1 + num2
    
def multiply(num1,num2):
    return num1 * num2
    
def pow(num1,num2):
    return num1 ** num2