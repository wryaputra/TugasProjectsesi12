def cmToMeter(cm):
    return cm / 100

def meterToCm(meter):
    return meter * 100