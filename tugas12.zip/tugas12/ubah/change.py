def binary(decim):
    return bin(decim)
    
def octal(decim):
    return oct(decim)
    
def hexa(decim):
    return hex(decim)